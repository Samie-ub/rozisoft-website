module.exports = {
    secretKey: 'iDJmlpi3sg',
  };